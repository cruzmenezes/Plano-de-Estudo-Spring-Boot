package com.primeiroRest.PrimeiroRest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrimeiroRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrimeiroRestApplication.class, args);
	}

}
